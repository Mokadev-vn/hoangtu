

<!DOCTYPE html>
<title> DatLeChin.Com </title>
<html lang="en">
<head>
    <audio autoplay id="audio" preload="auto" height="0" width="0" volume="0">
      <source src="bg.mp3">
        <script>
				var audio = document.currentScript.parentElement;
				audio.volume = 0.9;
      </script>
    </audio>

<ul id="nav-one" class="nav">
<link rel="stylesheet" href="css/style.css">

<link rel="icon" href="favicon.png">
<link href="css/preloader.css" rel="stylesheet">
<link href="css/highstl.css" rel="stylesheet">
<link href="css/animate.css" rel="stylesheet">
<link href="css/Shake.css" rel="stylesheet">
<script src="js/jquery.js"></script>
<script src="js/plugins.min.js"></script>
<script src="js/main.js"></script>
<script src="js/kill.js"></script>
<style>
@font-face{font-family:Pompadur;src:url(fonts/font.eot);src:local(pompadur),url(fonts/font.ttf);}h1{font-family:Pompadur,'Comic Sans MS',cursive;}
@font-face{font-family:Bazy;src:url(fonts/bazy.eot);src:local(bazy),url(fonts/bazy.ttf);}
body, a, a:link{cursor:url(images/cursor/cursor.cur), default;} a:hover {cursor:url(images/cursor/cursor2.cur),pointer;}
</style>
<div id="loader-wrapper"><div id="loader"></div>
<div class="loader-section section-left"></div>
<div class="loader-section section-right"></div> 
</div>
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false" onkeydown="return false">
<a href="#" id="autoid"> </a>
<style>body{overflow:hidden}</style>

<div id="star" class="video mask overlay">
<div class="video-fallback"></div>
<video id="video" muted autoplay loop>
<source src="OwO.mp4" type="video/mp4"/>
</video>

<script>setTimeout(function(){document.getElementById("video").play();}, 3000);</script>
<canvas class="cover"></canvas>
</div>
<div class="kill-feed"><div><span class="player t"></span><span class="weapons"><img height="20"/><img width="30" height="26" src="images/headshot.png"/></span><span class="player ct"></span></div></div>

<div class="pageoverlay">
<div class="lightbox">
<div class="awrapper">
<div class="titles animated rubberBand" style="animation-delay: 6s;">
<div class="animated zoomIn" style="animation-delay: 4s;">

<div class="glitch" data-text="DATLECHIN">
    <span class="glitch__color glitch__color--red">DATLECHIN</span>
    <span class="glitch__color glitch__color--blue">DATLECHIN</span>
    <span class="glitch__color glitch__color--green">DATLECHIN</span>
    <span class="glitch__main">DATLECHIN</span>
</div>
</div></div>
<div class="media animated fadeInUpBig" style="animation-delay: 5s;">

<center>
<font color="#FFFFFF"><p class="marq" class="strokeme">
<a class="hvr-grow" target="_blank" href="https://www.facebook.com/Dat.Viruss.Tml.Official" title="Facebook">Facebook</a> -  
<a class="hvr-grow" target="_blank" href="https://datlechin.com" title="Website">Website</a>
</p>
</font>
</center>
</ul>
<script>var beepOne = $("#audio")[0];
$("#nav-one div")
.mouseenter(function() {
beepOne.play();
});</script>
</div>
</span>
<div class='clear'></div>
</div><div class='widget HTML' data-version='1' id='HTML4'>
<div class='widget-content'>
</div>
<div class="animated zoomIn" style="animation-delay: 1s;">
</div></div>
<div class="pagebottom">
</div>
<script>$(document).ready(function() {setTimeout(function(){$('body').addClass('loaded');$('h1').css('color','#222222');}, 2000);});</script>
</html>